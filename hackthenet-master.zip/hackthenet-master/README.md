# Hack The Net (HTN)

The original source code of different versions of the then
popular browser game Hack The Net (HTN) including their
self written bulletin board htnBB.

Everything was licensed under CC BY-NC-SA 2.0 DE.
