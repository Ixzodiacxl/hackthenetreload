<div class="content" id="public-doc-impressum">

<h2>Impressum</h2>

<div id="impressum-partner">
<h3>Ansprechpartner</h3>
<p>Hier unbedingt Name + Adresse eintragen!</p>
</div>

<div class="important"><h3>Haftungshinweis</h3>
<p>Trotz sorgf�ltiger inhaltlicher Kontrolle �bernehmen wir keine Haftung f�r die Inhalte externer Links. F�r den Inhalt der verlinkten Seiten sind ausschlie�lich deren Betreiber verantwortlich.</p>
</div>

<div id="team-kings">
<h3>Wichtig!</h3>
<p>Der Quellcode dieses Spiels stammt im Original von <a href="http://www.hackthenet.org/">www.hackthenet.org</a>.
Dieser Hinweis darft nicht entfernt werden!</p>
</div>

</div>