<?php
header('Location: pub.php');
?>
