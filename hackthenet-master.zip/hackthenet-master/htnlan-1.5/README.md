# htnlan_1.5
HTN.LAN 1.5 by Schnitzel.

    
### Anforderungen von HTN.LAN:

- PHP Version 4.x
- MySQL Version 4.x

Mit anderen Versionen kann keine Garantie auf Funktionalität gegeben werden!

                                              
### Installationsanleitung:

1. ZIP entpacken
2. Dateien auf Webserver kopieren
3. pub.php aufrufen
4. Installations-Script durchlaufen
