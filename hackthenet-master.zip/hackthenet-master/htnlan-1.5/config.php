<?

// HTN.LAN hat nun ein Installations-Script!
// Einfach das Game aufrufen, dann wird automatisch das Installations-Script gestartet.

?>