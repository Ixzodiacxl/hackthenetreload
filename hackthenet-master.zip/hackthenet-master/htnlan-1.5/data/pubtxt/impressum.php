<div class="content" id="public-doc-impressum">

<h2>Impressum</h2>
<p>
Mit Urteil vom 12. Mai 1998 hat das Landgericht Hamburg entschieden, da� man durch das Anbringen eines Querverweises (Links) die Inhalte der verwiesenen Seite ggf. mit zu verantworten hat. Dies kann nur dadurch verhindert werden, da� man sich ausdr�cklich von diesen Inhalten distanziert. F�r alle Querverweise auf dieser Seite gilt: Ich betone ausdr�cklich, da� ich keinerlei Einflu� auf die Gestaltung und die Inhalte der gelinkten Seiten habe. Deshalb mu� ich mich hiermit ausdr�cklich von allen Inhalten aller hier zugewiesenen Seiten distanzieren und mache mir ihre Inhalte nicht zu eigen.
</p>

</div>
