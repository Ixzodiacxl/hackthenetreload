
 _    _ _______ _   _   _               _   _     __   _____ 
| |  | |__   __| \ | | | |        /\   | \ | |   /_ | | ____|
| |__| |  | |  |  \| | | |       /  \  |  \| |    | | | |__  
|  __  |  | |  | . ` | | |      / /\ \ | . ` |    | | |___ \ 
| |  | |  | |  | |\  |_| |____ / ____ \| |\  |    | |_ ___) |
|_|  |_|  |_|  |_| \_(_)______/_/    \_\_| \_|    |_(_)____/ 
				                 by Schnitzel

   _         __            _                                 
  /_\  _ _  / _|___ _ _ __| |___ _ _ _  _ _ _  __ _ ___ _ _  
 / _ \| ' \|  _/ _ \ '_/ _` / -_) '_| || | ' \/ _` / -_) ' \ 
/_/ \_\_||_|_| \___/_| \__,_\___|_|  \_,_|_||_\__, \___|_||_|
                                              |___/          
Anforderungen von HTN.LAN:

- PHP Version 4.x
- MySQL Version 4.x

Mit anderen Versionen kann keine Garantie auf Funktionalit�t gegeben werden!

 ___         _        _ _      _   _          
|_ _|_ _  __| |_ __ _| | |__ _| |_(_)___ _ _  
 | || ' \(_-<  _/ _` | | / _` |  _| / _ \ ' \ 
|___|_||_/__/\__\__,_|_|_\__,_|\__|_\___/_||_|
                                              
Installationsanleitung:

1. ZIP entpacken
2. Dateien auf Webserver kopieren
3. pub.php aufrufen
4. Installations-Script durchlaufen
5. Viel Spass

 ___                      ___ 
| __| _ __ _ __ _ ___ _ _|__ \
| _| '_/ _` / _` / -_) ' \ /_/
|_||_| \__,_\__, \___|_||_(_) 
            |___/             

Bei Fragen:

Als erstes UNBEDINGT lesen: http://www.htn-lan.com/index.php?option=com_smf&Itemid=77&expv=0&topic=21.0

Danach in der FAQ nachschauen: http://www.htn-lan.com/index.php?option=com_mambowiki&Itemid=98

erst dann im Forum fragen: http://www.htn-lan.com/index.php?option=com_smf&Itemid=77

