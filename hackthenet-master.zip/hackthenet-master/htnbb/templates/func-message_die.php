<div class="content">
<h2>HackTheNet</h2>
<?php
/**
 * function message_die() template.
 * @package     Templates
 * @subpackage  funcs
 * @see message_die()
 **/
 
echo '<div class="' . $type . '">';
echo '<h3>' . $caption . '</h3><p>';
echo $error_message;

?></p>
</div>
</div>