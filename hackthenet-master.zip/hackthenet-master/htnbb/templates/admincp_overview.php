<div class="content" id="admin">
<h2>Administration</h2>
<?php
 include 'templates/_admin_navi.php';
 echo '<div class="subnavi_content">';
?>

<h3>Gedon Burning Board Administratrionsoberfl&auml;che</h3>
<p>Hier wird gearbeitet!</p>

</div></div>