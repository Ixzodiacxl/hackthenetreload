<?php
header('Location: pub.htn');
?>
