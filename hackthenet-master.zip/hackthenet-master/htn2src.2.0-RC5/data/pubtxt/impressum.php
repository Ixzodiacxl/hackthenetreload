<div class="content" id="public-doc-impressum">

<h2>Impressum</h2>

<h3>Verantwortlicher</h3>
<p>
blub</p>
<p>E-Mail: blub<br />
Internet: blub</p>

<p>Haftungshinweis: Trotz sorgf�ltiger inhaltlicher Kontrolle �bernehmen wir keine Haftung f�r die Inhalte externer Links. F�r den Inhalt der verlinkten Seiten sind ausschlie�lich deren Betreiber verantwortlich.</p>

</div>
